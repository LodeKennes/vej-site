# Test-set sources

The r5 test file (SHA-256 `ac1b11d62e55c6094101f71790f5bcd326b1f32afb91311bb334238036311265`) contains 14,286 decisions built from:

| Source | Publisher revision | Licence |
| --- | --- | --- |
| Schema-Guided Dialogue (Rastogi et al., 2020), Flights and Hotels services | `e852981ae34990f4358979625854259302feaa78` | CC BY-SA 4.0 |
| HelpSteer (Wang et al., 2023), helpfulness ratings | `3ca5d59c1bc1080af195b4254e7407db60b6f450` | CC BY 4.0 |

`test_decisions.tsv` lists each decision's identifier, group, schema family,
type, number of outcomes, target outcome and the SHA-256 of its canonical JSON
row (`json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(",", ":"))`,
UTF-8). A portable script that rebuilds the file from the publisher data is not
yet available; the file is available from the author on request.

## Licences

Decision identifiers, candidate keys and targets are adaptations of the
sources above and are shared under their licences (SGD: CC BY-SA 4.0;
HelpSteer: CC BY 4.0), with attribution to their authors. Vej's predictions,
the baseline predictions produced for this study and the benchmark records
are released under CC BY 4.0. The Qwen3.5 baseline outputs were produced with
Apache-2.0 models.
