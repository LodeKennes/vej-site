# Supplementary material

- `test_decisions.tsv`: identifier, group, schema family, type, outcome count,
  target and SHA-256 of every test decision; `SOURCES.md` gives source pins.
- `predictions/*.jsonl.gz`: per-decision outputs of Vej (PyTorch reference,
  vLLM, and vLLM with prefix caching), Vej alpha1, every prompted baseline and
  both controls (probabilities, validity, failure reason; raw text for
  verbalised baselines), plus the order-reversal records (`*-reversed`).
- `benchmark/*.json`: every runtime benchmark run (36 fresh servers).
- `tuning.json`, `benchmark.json` (+ manifests): the 300 validation decision IDs
  used for template selection and the 1,000 test decision IDs used for timing.
- `template-selection.json`: validation scores of every template variant and the
  frozen selection, bound to the evaluation-code hash.
- `MANIFEST.json`: SHA-256 of every file.

The evaluation and analysis code depends on Vej's source and is available from
the author on request, as are the test file, Vej's weights and its training
code. The protocol is reproduced in the paper's appendix.
